from animal_shelter import AnimalShelter

# Define the connection variables
USER = 'aacuser'
PASS = 'VUDEHSNHUCS340'
HOST = 'nv-desktop-services.apporto.com'
PORT = 31593
DB = 'AAC'
COL = 'animals'

# Instantiate the AnimalShelter class
shelter = AnimalShelter(USER, PASS, HOST, PORT, DB, COL)

# Test data for the create operation
sample_data = {"animal_id": "A123456", "name": "Fido", "breed": "Labrador"}

# Test the create method
create_result = shelter.create(sample_data)
print(f'Create result: {create_result}')

# Test the read method
read_result = shelter.read({"animal_id": "A123456"})
print(f'Read result: {read_result}')
